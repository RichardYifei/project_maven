create definer = root@localhost view std2 as
select `studentdb`.`student`.`SNO`   AS `SNO`,
       `studentdb`.`student`.`SNAME` AS `SNAME`,
       `studentdb`.`student`.`SEX`   AS `SEX`,
       `studentdb`.`student`.`SAGE`  AS `SAGE`,
       `studentdb`.`student`.`SDEPT` AS `SDEPT`
from `studentdb`.`student`
where (`studentdb`.`student`.`SAGE` < 25);

