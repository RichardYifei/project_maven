create definer = root@localhost trigger trig10
    before update
    on customer
    for each row
begin
if(new.balance<0) then
set new.balance = 0;
end if;
end;

