create
    definer = root@localhost procedure per1()
begin
declare num int;
set num=1;
while num<100 do
insert into per1(record) values("1","1","1",now(),1,1);
set num=num+1;
end while;
end;

