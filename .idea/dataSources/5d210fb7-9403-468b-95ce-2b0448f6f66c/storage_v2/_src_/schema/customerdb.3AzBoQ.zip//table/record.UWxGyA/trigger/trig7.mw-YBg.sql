create definer = root@localhost trigger trig7
    before insert
    on record
    for each row
    set new.totalprice=new.amount*(select price from product where id=new.pid);

