create definer = root@localhost trigger trig9
    before insert
    on customer
    for each row
begin
if(new.balance<0) then
set new.balance = 0;
end if;
end;

