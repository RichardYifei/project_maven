create definer = root@localhost trigger trig8
    before update
    on customer
    for each row
begin
if(new.sex!="F" or "M") then
set new.sex = "F";
end if;
end;

