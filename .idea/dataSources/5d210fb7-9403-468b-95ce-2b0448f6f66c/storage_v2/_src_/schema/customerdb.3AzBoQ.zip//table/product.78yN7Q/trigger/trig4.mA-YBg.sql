create definer = root@localhost trigger trig4
    before delete
    on product
    for each row
    delete from record where pid=old.id;

