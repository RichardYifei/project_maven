create definer = root@localhost trigger trig6
    before insert
    on record
    for each row
begin
if(new.amount>(select amount from product where id = new.pid)) then
set new.id = NULL;
end if;
end;

