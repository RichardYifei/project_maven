create definer = root@localhost trigger trig1
    before update
    on customer
    for each row
begin 
set FOREIGN_KEY_CHECKS = 0;
update record set cid = new.id where cid = old.id;
set FOREIGN_KEY_CHECKS = 1;
end;

