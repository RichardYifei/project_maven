create definer = root@localhost trigger trig2
    before update
    on product
    for each row
begin
set FOREIGN_KEY_CHECKS = 0;
update record set pid = new.id where pid = old.id;
set FOREIGN_KEY_CHECKS = 1;
end;

