create definer = root@localhost trigger trig5
    before insert
    on record
    for each row
begin
if(select count(*) from record where cid = new.cid group by cid) then
set new.id = NULL;
end if;
end;

