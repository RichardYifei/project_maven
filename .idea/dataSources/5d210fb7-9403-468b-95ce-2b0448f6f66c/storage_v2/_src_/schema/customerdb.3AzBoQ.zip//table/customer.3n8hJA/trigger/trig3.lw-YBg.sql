create definer = root@localhost trigger trig3
    before delete
    on customer
    for each row
    delete from record where cid = old.id;

